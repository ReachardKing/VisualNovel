spawnpoint 'a_m_y_skater_01' {x = 450.41, y = -992.7, z = 30.6}
spawnpoint 'a_m_y_skater_01' {x = 450.41, y = -992.7, z = 30.69}
spawnpoint 'a_m_y_skater_01' {x = 1849.95, y = 3696.69, z = 34.26}
spawnpoint 'a_m_y_skater_01' {x = 1849.39, y = 3689.16, z = 34.26}
spawnpoint 'a_m_y+skater_01' {x = 1113.19, y = -849.1, z = 13.45}
spawnpoint 'a_m_y_skater_01' {x = -556.28, y = -131.93, z = 38.1}
spawnpoint 'a_m_y_skater_01' {x = 634.41, y = 0.74, z = 82.77} -- PD Vine
spawnpoint 'a_m_y_skater_01' {x = 823.43, y = -1290.50, z = 28.24}-- PD Lamesa
spawnpoint 'a_m_y_skater_01' {x = 358.01, y = -1582.51, z = 29.29} -- PD Davis
spawnpoint 'a_m_y_skater_01' {x = 2736.65, y = 3478.88, z = 55.65} -- SHHP 
spawnpoint 'a_m_y_skater_01' {x = 2506.3, y = -384.51, z = 94.12} -- PD Los Stantos Goverment Facility